import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div>
      <header>
        <h1>PRICING</h1>
      </header>
      <div className="box-holder">
        <div className="box">
          <p>User can use the platform Free of charge until they hit 100k in revenues to help the become a sustainable business.</p>
        </div>
        <div className="box">
          <p>After they hit 100k in revenue,we will keep in track of the time lenght it look them to hit that 6 figure mark. Then,We will set up commision fees of up to 10% going forward for the length it took them to hit the 6 figure mark.</p>
        </div>
        <div className="box">
          <p>But after this time frame, the commission fee will be optimized to be 3-5% depending on their revenue. The business is sustainable enough to self run and self sustain.</p>
        </div>
      </div>
      <nav>
        <ul id="horBar">
          <li><a href="home.html">PRICING</a></li>
          <li><a href="customer.html">ABOUT</a></li>
          <li><a href="products.html">CATAGORY</a></li>
          <li><a href="orders.html">HOME</a></li>
          <li><a href="reports.html">BLOGS</a></li>
          <li><a href="administrations.html">CART</a></li>
          <li><b><a href="about.html">SIGNUP</a></b></li>
        </ul>
      </nav>
            <div className='logo'>@EBA&HIS FRIENDS</div>
<div className='free'>FREE</div>
<div className ="trust">TRUST</div>
<div className = "standard">STANDARD</div>
      <a href="https://www.google.com/" className="my-button">Start Trial</a>
      
    </div>
  );
}

export default App;